﻿
//Namespaces used
using FlatRedBall;
using Klotski.Utilities;
using Microsoft.Xna.Framework;
using TomShane.Neoforce.Controls;

//Application namespace
namespace Klotski.States {
	/// <summary>
	/// Class description.
	/// </summary>
	public class StateTitle : State {
		private bool m_New;

		/// <summary>
		/// Class constructor.
		/// </summary>
		public StateTitle() : base(StateID.Title) {
			m_New = false;
			m_VisibleCursor = true;
		}

		public override void Initialize() {
			SpriteManager.AddToLayer(SpriteManager.AddSprite("redball.bmp"), m_Layer);
			Button A = new Button(Global.GUIManager);
			A.Init();
			A.Click += AClicked;
			A.Left = 300;
			Global.GUIManager.Add(A);
			m_Panel.Add(A);
		}

		private void AClicked(object sender, EventArgs e) {
			//
			Global.StateManager.GoTo(StateID.Game, null);
		}

		public override void OnEnter() {
			//
		}

		public override void Update(GameTime time) {
			if (!m_New) {
				m_New = true;
				//Global.StateManager.GoTo(StateID.Game, null, true);
			}
		}
	}
}
